document.addEventListener('DOMContentLoaded', function () {
    // Función para redirigir a la página de saldo
    function redirectToSaldo() {
        window.location.href = 'saldo.html';
    }

    // Agregar evento al botón de login
    const btnLogin = document.getElementById('btnLogin');
    btnLogin.addEventListener('click', redirectToSaldo);
});




const setUp = () => {
    const burger = document.getElementById("mene2");
    burger.addEventListener("click", () => {
        console.log("entro");
        const menu = document.getElementById("mene");
        menu.classList.remove("hidden");
    });
    const slideMenu = document.getElementById("mene");
    slideMenu.addEventListener("click", () => {
        slideMenu.classList.add("hidden")
    })
}

const main = () => {
    setUp();
    console.log("hello");
}

main()

document.addEventListener('DOMContentLoaded', function () {
    // Función para cambiar de pantalla
    function cambiarPantalla(pantalla) {
        // Cargar contenido de la pantalla deseada
        fetch(`${pantalla}.html`)
            .then(response => response.text())
            .then(html => {
                document.body.innerHTML = html; // Reemplaza todo el contenido del body con el contenido de la pantalla
                // Si la pantalla es la de inicio de sesión, entonces agregamos el evento al botón de login
                if (pantalla === 'login') {
                    const btnLogin = document.getElementById('btnLogin');
                    btnLogin.addEventListener('click', login);
                }
            })
            .catch(error => console.error('Error al cargar la pantalla', error));
    }

    // Función de inicio de sesión
    function login() {
        // Aquí puedes agregar la lógica de inicio de sesión
        // Por ejemplo, podrías obtener los valores de usuario y contraseña y realizar la autenticación

        // Luego de la autenticación, podrías redirigir a la página de "saldo" o cualquier otra página
        cambiarPantalla('saldo'); // Redirige a la página de "saldo"
    }

    function redirectToSaldo() {
        window.location.href = 'saldo.html';
    }

    // Por defecto, cargar la pantalla de inicio de sesión al iniciar la aplicación
    // cambiarPantalla('login');
});



